The budget follows directly from the three project aims.

**Aim 1 — Federated infrastructure.** Extending the NDTD DataSHIELD/Armadillo platform with Bayesian capability is principally an engineering effort, led by a UMCG (MGE) software developer (0.5 FTE, 3 years) who implements and validates these via the federated analysis protocol Flower. A central data manager at UMCG (UCP) (0.15 FTE, 4 years) coordinates harmonisation and upload of (i) previous clinical data held at partner sites, (ii) ongoing collected data, and (iii) the meta-data catalogue so data conforms to FAIR principles. Local data managers at the GGZ partners (GGZ inGeest, Pro Persona, Parnassia; 0.05 FTE each) assist on site, while research nurses help complete the data — a central research nurse (0.1 FTE) coordinating local research nurses (0.05 FTE each). This aim also covers catalogue hosting and annual server maintenance for the four federated nodes.

**Aim 2 — Recovery trajectories and prediction algorithm.** The scientific core is a PhD researcher at UMCG (MGE) (1.0 FTE, 4 years), who develops the Bayesian longitudinal models, identifies recovery trajectories across symptoms, functioning and treatment history, relates them to treatment sequences and discontinuation, and derives and validates the prediction algorithm.

**Aim 3 — Clinical decision-support prototype.** An Evidencio team — software developer, quality engineer and UX designer — guides validation of the algorithm and integrates it into their platform to prototype a clinical decision-support tool, supported by a premium platform subscription.

**Industry and patient involvement.** Compass Pathways joins the project group and meetings and makes its network available; Depressievereniging participates likewise, embedding the patient perspective in design and interpretation. International conference travel and open-access publication ensure dissemination across the 48-month project.

**In-kind contributions.** Alongside the PPS-subsidie, partners co-finance the project: UMCG, Evidencio and the GGZ institutions contribute staff effort in kind, while Compass Pathways provides in-cash and in-kind contributions.
