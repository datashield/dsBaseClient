#-------------------------------------------------------------------------------
# Copyright (c) 2019-2022 University of Newcastle upon Tyne. All rights reserved.
# Copyright (c) 2022-2025 Arjuna Technologies, Newcastle upon Tyne. All rights reserved.
#
# This program and the accompanying materials
# are made available under the terms of the GNU Public License v3.0.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

#
# Set up
#

# context("rUnifDS::smk::setup")

set.standard.disclosure.settings()

#
# Tests
#

# context("rUnifDS::smk::simple")
test_that("simple rUnifDS, by name", {
    n   <- 8
    min <- 2
    max <- 6

    res <- rUnifDS(n, "min", "max", 8)

    expect_equal(class(res), "numeric")
    expect_length(res, 8)
    expect_true(res[1] >= 0)
    expect_true(res[2] >= 0)
    expect_true(res[3] >= 0)
    expect_true(res[4] >= 0)
    expect_true(res[5] >= 0)
    expect_true(res[6] >= 0)
    expect_true(res[7] >= 0)
    expect_true(res[8] >= 0)
})

test_that("simple rUnifDS, direct", {
    n   <- 8
    min <- 2
    max <- 6

    res <- rUnifDS(n, min, max, 8)

    expect_equal(class(res), "numeric")
    expect_length(res, 8)
    expect_true(res[1] >= 0)
    expect_true(res[2] >= 0)
    expect_true(res[3] >= 0)
    expect_true(res[4] >= 0)
    expect_true(res[5] >= 0)
    expect_true(res[6] >= 0)
    expect_true(res[7] >= 0)
    expect_true(res[8] >= 0)
})

test_that("rUnifDS fails when min references nonexistent object", {
    expect_error(rUnifDS(8, "nonexistent_obj", 1, 9), "does not exist")
})

test_that("rUnifDS fails when max references nonexistent object", {
    expect_error(rUnifDS(8, 0, "nonexistent_obj", 9), "does not exist")
})

#
# Done
#

# context("rUnifDS::smk::shutdown")

# context("rUnifDS::smk::done")
