#-------------------------------------------------------------------------------
# Copyright (c) 2019-2022 University of Newcastle upon Tyne. All rights reserved.
# Copyright (c) 2022-2025 Arjuna Technologies, Newcastle upon Tyne. All rights reserved.
#
# This program and the accompanying materials
# are made available under the terms of the GNU Public License v3.0.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

#
# Set up
#

# context("isValidDS::smk::setup")

set.standard.disclosure.settings()

#
# Tests
#

# context("isValidDS::smk::character")
test_that("simple isValidDS, character", {
    input <- "value"

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, FALSE)
})

test_that("simple isValidDS, character vector", {
    input <- c("value1", "value2", "value3", "value4")

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, TRUE)
})

# context("isValidDS::smk::integer")
test_that("simple isValidDS, integer", {
    input <- 1L

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, FALSE)
})

test_that("simple isValidDS, integer vector", {
    input <- c(1L, 2L, 3L, 4L)

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, TRUE)
})

# context("isValidDS::smk::numeric")
test_that("simple isValidDS, numeric", {
    input <- 1.1

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, FALSE)
})

test_that("simple isValidDS, numeric vector", {
    input <- c(1.1, 2.1, 3.1, 4.1)

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, TRUE)
})

# context("isValidDS::smk::logical")
test_that("simple isValidDS, logical, FALSE", {
    input <- FALSE

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, FALSE)
})

test_that("simple isValidDS, logical, TRUE", {
    input <- TRUE

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, FALSE)
})

test_that("simple isValidDS, logical vector", {
    input <- c(FALSE, TRUE, FALSE, TRUE)

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, TRUE)
})

test_that("simple isValidDS, factor", {
    input <- as.factor("a")

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, FALSE)
})

test_that("simple isValidDS, factor vector", {
    input <- as.factor(c("a", "a", "a", "a", "b", "b", "b", "b"))

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, TRUE)
})

test_that("simple isValidDS, factor vector", {
    input <- as.factor(c("a", "b", "c", "d", "e", "f"))

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, FALSE)
})

# context("isValidDS::smk::data.frame")
test_that("simple isValidDS, data.frame", {
    input <- data.frame(v1 = c(0.0, 1.0, 2.0, 3.0, 4.0), v2 = c(4.0, 3.0, 2.0, 1.0, 0.0))

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, TRUE)
})

# context("isValidDS::smk::array")
test_that("isValidDS throws error for a 1-d array", {
    input <- array(c(0.0, 1.0, 2.0, 3.0, 4.0))

    expect_error(isValidDS("input"), regexp = "must be of type")
})

# context("isValidDS::smk::matrix")
test_that("simple isValidDS, matrix", {
    input <- matrix(c(0.0, 1.0, 2.0, 3.0, 4.0))

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, TRUE)
})

# context("isValidDS::smk::data.matrix")
test_that("simple isValidDS, data.matrix", {
    input <- data.matrix(data.frame(v1 = c(0.0, 1.0, 2.0, 3.0, 4.0), v2 = c(4.0, 3.0, 2.0, 1.0, 0.0)))

    res <- isValidDS("input")

    expect_equal(class(res$valid), "logical")
    expect_length(res$valid, 1)
    expect_equal(res$valid, TRUE)
})

# context("isValidDS::smk::date")
test_that("isValidDS throws error for a date", {
    input <- Sys.Date()

    expect_error(isValidDS("input"), regexp = "must be of type")
})

test_that("isValidDS returns the class of the input", {
    input <- c(1.1, 2.1, 3.1, 4.1)

    res <- isValidDS("input")

    expect_equal(res$class, "numeric")
})

test_that("isValidDS throws error when object does not exist", {
    expect_error(isValidDS("nonexistent_object"), regexp = "does not exist")
})

test_that("special isValidDS, NA", {
    input <- NA

    res <- isValidDS("input")

    expect_equal(res$valid, FALSE)
})

test_that("special isValidDS, NULL", {
    input <- NULL

    expect_error(isValidDS("input"), regexp = "must be of type")
})
