#-------------------------------------------------------------------------------
# Copyright (c) 2019-2022 University of Newcastle upon Tyne. All rights reserved.
# Copyright (c) 2022-2025 Arjuna Technologies, Newcastle upon Tyne. All rights reserved.
#
# This program and the accompanying materials
# are made available under the terms of the GNU Public License v3.0.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------
#
# Datashield test suite set up
#

# context("setup - start")

library(RANN)
library(stringr)
library(lme4)

source("disclosure/set_disclosure_settings.R")
source("random/set_random_seed_settings.R")

options(perf.profile = "perf_files/performance_refactor_profile.csv")
source("perf_tests/perf_rate.R")

# context("setup - done")
