#!/usr/bin/env bash
# Build a dsBase tarball with the privacy control level set to "permissive".
# Temporarily flips inst/DATASHIELD from "banana" to "permissive", builds, then
# restores the original file (even if the build fails). The resulting tarball is
# copied to the dsBaseClient repo root.
set -euo pipefail

REPO="$HOME/git-repos/ds-core/dsBase"
DS_FILE="$REPO/inst/DATASHIELD"
BACKUP="$DS_FILE.bak"
CLIENT_REPO="$HOME/git-repos/ds-core/dsBaseClient"

cp "$DS_FILE" "$BACKUP"
trap 'mv "$BACKUP" "$DS_FILE"' EXIT

sed -i '' 's/default.datashield.privacyControlLevel="banana"/default.datashield.privacyControlLevel="permissive"/' "$DS_FILE"

cd "$REPO"
R CMD build .

VERSION="$(grep -m1 '^Version:' "$REPO/DESCRIPTION" | awk '{print $2}')"
TARBALL="dsBase_${VERSION}.tar.gz"

cp "$REPO/$TARBALL" "$CLIENT_REPO/$TARBALL"
echo "Copied $TARBALL to $CLIENT_REPO"
