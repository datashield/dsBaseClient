# Build dsBase and install on Armadillo, then run server-side tests
#
# Usage: Rscript scripts/build_and_install.R

cat("=== Building dsBase package ===\n")
pkg_path <- devtools::build()
cat("Built:", pkg_path, "\n")

cat("\n=== Logging into Armadillo ===\n")
library(MolgenisArmadillo)
armadillo.login_basic("http://localhost:8080", "admin", "admin")

cat("\n=== Installing dsBase on Armadillo ===\n")
armadillo.install_packages(pkg_path)

cat("\n=== Running server-side unit tests ===\n")
results <- devtools::test(filter = "smk-(abs|asCharacter|asDataMatrix|asInteger|asList|asLogical|asMatrix|asNumeric|sqrt|exp|log)DS")

cat("\n=== Done ===\n")
